# Famillies-Interior
![Famillies Interior](https://repository-images.githubusercontent.com/200733774/f60d3d00-b7e4-11e9-8881-e151708f6b0d)
Video: https://youtu.be/9JZyucEjiBw
# Installation
1. Add the `familiesint` folder to your FiveM resources directory.
2. Inside the **server.cfg** file type `start familiesint`.
